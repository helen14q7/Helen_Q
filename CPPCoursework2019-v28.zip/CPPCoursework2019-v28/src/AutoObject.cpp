#include"header.h"
#include "AutoObject.h"
#include "BaseEngine.h"
#include"MovementPosition.h"


//AutoObject::AutoObject(BaseEngine* pEngine)
//	: DisplayableObject(400, -58, pEngine, 58, 58, true)
//{
	//setVisible(true);
	
	//color = 0x000000;
//}
AutoObject::AutoObject(BaseEngine* pEngine, std::string strURL,int mul)
	: DisplayableObject(400, -58, pEngine, 58, 58, true), image(pEngine->loadImage(strURL, false))
{
	
	image = image.shrinkBy(mul);
	
}


//AutoObject::AutoObject(BaseEngine* pEngine,unsigned int color, std::string strURL,int mul)
//	: DisplayableObject(400, 5, pEngine, 58, 58, true),color(color), image(pEngine->loadImage(strURL, false))
//{
	//image = new SimpleImage(pEngine->loadImage(strURL, false));
	//setVisible(true);

	//image = image.shrinkBy(mul);
	//image = image.shrinkBy(4);
//}


AutoObject::~AutoObject()
{
}


 void AutoObject::virtDraw() 
{
		
	 if (isVisible())
	 {

		 image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX + m_iStartDrawPosX, m_iCurrentScreenY + m_iStartDrawPosY, m_iDrawWidth, m_iDrawHeight);

	 }	
}


 void AutoObject::setMove(int iStartTime, int iEndTime, int iCurrentTime,
	 int iStartX, int iStartY, int iEndX, int iEndY)
 {
	 move.setup(iStartX, iStartY, iEndX, iEndY, iStartTime, iEndTime);
	 
	 move.calculate(iCurrentTime);
	 m_iCurrentScreenX = move.getX();

	 m_iCurrentScreenY = move.getY();
	 redrawDisplay();


 }

