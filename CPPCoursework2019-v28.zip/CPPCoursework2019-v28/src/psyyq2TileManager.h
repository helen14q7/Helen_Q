#pragma once
#include "TileManager.h"

class psyyq2TileManager :
	public TileManager
{
public:
	psyyq2TileManager();
	~psyyq2TileManager();

	virtual void virtDrawTileAt(
		BaseEngine* pEngine,
		DrawingSurface* pSurface,
		int iMapX, int iMapY,
		int iStartPositionScreenX, int iStartPositionScreenY) const;
};