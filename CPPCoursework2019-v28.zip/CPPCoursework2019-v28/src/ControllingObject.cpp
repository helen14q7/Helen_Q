#include"header.h"
#include "DisplayableObject.h"
#include"BaseEngine.h"
#include "ControllingObject.h"
#include"psyyq2TileManager.h"
#include"TileManager.h"



ControllingObject::ControllingObject(BaseEngine* pEngine, psyyq2TileManager* ptm)
	: DisplayableObject(365, 500, pEngine, 70, 68, true), ptm(ptm)
{
	
}
ControllingObject::ControllingObject(BaseEngine* pEngine, psyyq2TileManager* ptm, std::string strURL)
	: DisplayableObject(365, 500, pEngine, 70, 68, true), ptm(ptm), image(pEngine->loadImage(strURL, false))
{
	image = image.shrinkBy(1);
}


ControllingObject::~ControllingObject()
{
}





void ControllingObject::virtDraw()
{

	//getEngine()->drawForegroundRectangle(
	//	m_iCurrentScreenX, m_iCurrentScreenY,
	//	m_iCurrentScreenX + m_iDrawWidth - 1,
	//	m_iCurrentScreenY + m_iDrawHeight - 1,
	//	0xF0E68C);
	image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX + m_iStartDrawPosX, m_iCurrentScreenY + m_iStartDrawPosY, m_iDrawWidth, m_iDrawHeight);
	//image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX , m_iCurrentScreenY, m_iDrawWidth, m_iDrawHeight);

}


void ControllingObject::virtDoUpdate(int iCurrentTime)
{
	int move = 0;
	int back = 0;
	if (getEngine()->isKeyPressed(SDLK_LEFT))
	{
		m_iCurrentScreenX -= 15;
		move = 1;
	}
	if (getEngine()->isKeyPressed(SDLK_RIGHT)) {
		m_iCurrentScreenX += 15;
		move = 1;
	    back = 1;
	}
		//m_iCurrentScreenX += 15;
	if (m_iCurrentScreenX < 0)
		m_iCurrentScreenX = 0;
	if (m_iCurrentScreenX >= getEngine()->getWindowWidth() - m_iDrawWidth)
		m_iCurrentScreenX = getEngine()->getWindowWidth() - m_iDrawWidth;
	//m_oMovement.calculate(iCurrentTime);
	//m_iCurrentScreenX = m_oMovement.getX();
	///m_iCurrentScreenY = m_oMovement.getY();
	if (ptm->isValidTilePosition(m_iCurrentScreenX, m_iCurrentScreenY+33)&&move==1) {
		int tileX1 = ptm->getMapXForScreenX(m_iCurrentScreenX);
		int tileY1 = ptm->getMapYForScreenY(m_iCurrentScreenY+33);
		int iCurrentTile1 = ptm->getMapValue(tileX1, tileY1);

		int tileX2 = ptm->getMapXForScreenX(m_iCurrentScreenX);
		int tileY2 = ptm->getMapYForScreenY(m_iCurrentScreenY + 50.5);
		int iCurrentTile2 = ptm->getMapValue(tileX1, tileY1);
		
		if (back == 0) {
			ptm->setAndRedrawMapValueAt(tileX1+1 , tileY1, iCurrentTile1 + 1, getEngine(), getEngine()->getBackgroundSurface());
			ptm->setAndRedrawMapValueAt(tileX2 +1, tileY2, iCurrentTile2 + 1, getEngine(), getEngine()->getBackgroundSurface());
		}
		if (back == 1) {
			ptm->setAndRedrawMapValueAt(tileX1 - 1, tileY1, iCurrentTile1 + 1, getEngine(), getEngine()->getBackgroundSurface());
			ptm->setAndRedrawMapValueAt(tileX2 - 1, tileY2, iCurrentTile2 + 1, getEngine(), getEngine()->getBackgroundSurface());
		}
		//if((int x1l, int x1r, int y1t, int y1b, int x2l, int x2r, int y2t, int y2b)

		//redrawDisplay();
	}
	
	

	redrawDisplay();

}




int ControllingObject::getPosX()
{
	// TODO: �ڴ˴�����ʵ�ִ���.
	return m_iCurrentScreenX;
}


int ControllingObject::getPosY()
{
	// TODO: �ڴ˴�����ʵ�ִ���.
	return m_iCurrentScreenY;
}
