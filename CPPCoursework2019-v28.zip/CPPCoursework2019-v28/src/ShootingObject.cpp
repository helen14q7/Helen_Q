#include"header.h"
#include "ShootingObject.h"
#include "CollisionDetection.h"
#include"DisplayableObjectContainer.h"

extern int score;

ShootingObject::ShootingObject(BaseEngine* pEngine)
    :DisplayableObject(400, 5, pEngine, 25, 25, true)
{

}


ShootingObject::~ShootingObject()
{
}

void ShootingObject::setMove(int iStartTime, int iEndTime, int iCurrentTime,
	int iStartX, int iStartY, int iEndX, int iEndY)
{
	move.setup(iStartX, iStartY, iEndX, iEndY, iStartTime, iEndTime);
	//move.calculate(iCurrentTime);
	//move.calculate(iCurrentTime);
	//m_iCurrentScreenX = move.getX();
	//m_iCurrentScreenY = move.getY();


}

void ShootingObject::virtDoUpdate(int iCurrentTime)
{
	//int i = 0;
	if (!isVisible()) {
		//redrawDisplay();
		//redrawDisplay();
		
		m_iCurrentScreenX = -50;
		m_iCurrentScreenY =-50 ;
		redrawDisplay();
		return;
	}

	move.calculate(iCurrentTime);
	m_iCurrentScreenX = move.getX();
	m_iCurrentScreenY = move.getY();
	if (m_iCurrentScreenY > 25) {


		DisplayableObject* pObject;
		
		for (int iObjectId = 0;
			iObjectId<8;
				iObjectId++)

		{
			pObject = m_pEngine->getDisplayableObject(iObjectId);
			

			if (iObjectId == 0) {
				continue;
			}
			if (pObject == this)
				continue;
			if (pObject == nullptr)
				continue;
		//	if(iObjectId == 9) {

		//		if(m_iCurrentScreenX<pObject->m_iCurrentScreenX+pObject->)


		//	}

			if (CollisionDetection::checkCircles(pObject->getXCentre(), pObject->getYCentre(), m_iCurrentScreenX, m_iCurrentScreenY, m_iDrawWidth+(pObject->getDrawingRegionBottom()-pObject->getYCentre()))) {
			//	if (iObjectId == 9){
			//		printf("HIIIIIIIIIIIIIIIIIIIIIIIIIIIIi");
			//	}
			//	printf("EIIIIIIIIIIIIIIIIIIIIIIIIIIIIi");
			//if(pObject0>getDrawingRegionLeft)
			//if(getXCentre()- pObject->getDrawingRegionLeft() < pObject->getDrawWidth()+getDrawWidth()/2&& pObject->getDrawingRegionRight()- getXCentre() < pObject->getDrawWidth() + getDrawWidth() / 2&&getYCentre()-pObject->getDrawingRegionTop()<pObject->getDrawHeight()+getDrawWidth()/2)
			//if(pObject->getDrawingRegionLeft()-getDrawWidth()/2 <getXCentre()< pObject->getDrawingRegionRight()+getDrawWidth()/2&&pObject->getDrawingRegionTop()-getDrawWidth()/2 < getYCentre()<pObject->getDrawingRegionBottom()+getDrawWidth()/2){	
				score = score + 10;
				//i = 1;
				
				setVisible(false);
				pObject->setVisible(false);
				
			}

		}
	}




	redrawDisplay();
}


void ShootingObject::virtDraw()
{
	getEngine()->drawForegroundOval(
		m_iCurrentScreenX - m_iDrawWidth / 2 + 1,
		m_iCurrentScreenY - m_iDrawHeight / 2 + 1,
		m_iCurrentScreenX + m_iDrawWidth / 2 - 1,
		m_iCurrentScreenY + m_iDrawHeight / 2 - 1, 0x000000);
	//image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX + m_iStartDrawPosX, m_iCurrentScreenY + m_iStartDrawPosY, m_iDrawWidth, m_iDrawHeight);
	//getEngine()->drawForegroundOval(
		//m_iCurrentScreenX ,
		//m_iCurrentScreenY ,
		//m_iCurrentScreenX-20,
		//m_iCurrentScreenY -20, 0x000000);
}