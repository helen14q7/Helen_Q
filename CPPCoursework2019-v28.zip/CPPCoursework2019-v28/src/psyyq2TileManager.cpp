#include"header.h"
#include "psyyq2TileManager.h"
#include"TileManager.h"



psyyq2TileManager::psyyq2TileManager()
	: TileManager(17.5, 15, 54, 2)
{
}


psyyq2TileManager::~psyyq2TileManager()
{
}


void psyyq2TileManager::virtDrawTileAt(BaseEngine* pEngine, DrawingSurface*pSurface, int iMapX, int iMapY, int iStartPositionScreenX, int iStartPositionScreenY)const
{
	unsigned int iColour;
	int iMapValue = getMapValue(iMapX, iMapY);
	
	if (iMapY==0) {
		if (iMapX % 2 == 0) {
			if (iMapValue % 2 == 0) {
				iColour = 0x2F4F4F;
			}
			else {
				iColour = 0x008080;
			}
			
		}
		else {
			if (iMapValue % 2 == 0) {
				iColour = 0xFF8C00;
			}
			else {
				iColour = 0xFFC0CB;
			}
			//iColour = 0xF0E68C;
		}

	}
	if (iMapY == 1) {
			if (iMapX % 2 == 0) {
				if (iMapValue % 2 == 0) {
					iColour = 0xFF8C00;
				}
				else {
					iColour = 0xFFC0CB;
				}
			}
			else {
				if (iMapValue % 2 == 0) {
					iColour = 0x2F4F4F;
				}
				else {
					iColour = 0x008080;
				}
			}
		}
	//unsigned int iColour;
	//if (iMapValue%2 == 0)
	//{
	//	iColour = 0x2F4F4F;
	//}
	//else {
	//	iColour = 0xFFD700;
	//}
	//unsigned int iColour = 0x2F4F4F;

	pSurface->drawRectangle(
	//pSurface->drawOval(
		iStartPositionScreenX,
		iStartPositionScreenY,
		iStartPositionScreenX + getTileWidth() - 1,
		iStartPositionScreenY + getTileHeight() - 1,
		iColour);
}




