#pragma once
#include "PinObject.h"
#include"MovementPosition.h"
class ShootingObject :
	public DisplayableObject
{
public:
	ShootingObject(BaseEngine* pEngine);
	void setMove(int iStartTime, int iEndTime, int iCurrentTime,
		int iStartX, int iStartY, int iEndX, int iEndY);
	~ShootingObject();
protected:
	int iX;
	int iY;
	int i = 0;
	MovementPosition move;
public:
	void virtDoUpdate(int iCurrentTime);
	void virtDraw();
};

