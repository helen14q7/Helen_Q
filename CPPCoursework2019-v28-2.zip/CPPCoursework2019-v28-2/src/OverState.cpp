#include"header.h"
#include "OverState.h"


extern int score;
extern int life;
extern int rival;
OverState::OverState(Psyyq2Engine *pEngine)
	:pEngine(pEngine)
{
	
}


OverState::~OverState()
{

}


void OverState::virInitial()
{
	printf("ever the over?\n");
	pEngine->fillBackground(0x000000);

	image = ImageManager::loadImage("GameOver.jpg", true);
	image.renderImage(pEngine->getBackgroundSurface(), 0, 0, 118,141 ,
		image.getWidth(),image.getHeight());
	
	
	
}


void OverState::virKeyPress(int iKeyCode)
{
	switch (iKeyCode) {
	case SDLK_SPACE:
		printf("the exit?\n");
		pEngine->setExitWithCode(0);
		break;
	case SDLK_RETURN:
		score = 0;
		life = 5;
		rival = 2;
		printf("are u heere\n");
		pEngine->reStart();
		pEngine->virtInitialise();
		pEngine->redrawDisplay();
		break;
	}
}
