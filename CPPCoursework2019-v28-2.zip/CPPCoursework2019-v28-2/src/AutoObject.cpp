#include"header.h"
#include "AutoObject.h"
#include "BaseEngine.h"
#include"MovementPosition.h"


extern int rivaldir;

AutoObject::AutoObject(BaseEngine* pEngine, int iMapX, int iMapY)
	: DisplayableObject(iMapX*50, iMapY*50, pEngine, 50, 50, true),iMapX(iMapX),iMapY(iMapY)
{
	
	
	
}


//AutoObject::AutoObject(BaseEngine* pEngine,unsigned int color, std::string strURL,int mul)
//	: DisplayableObject(400, 5, pEngine, 58, 58, true),color(color), image(pEngine->loadImage(strURL, false))
//{
	//image = new SimpleImage(pEngine->loadImage(strURL, false));
	//setVisible(true);

	//image = image.shrinkBy(mul);
	//image = image.shrinkBy(4);
//}


AutoObject::~AutoObject()
{
}


 void AutoObject::virtDraw() 
{
		
	 if (isVisible())
	 {
		 if (rivaldir == 0) {
			 image = (getEngine()->loadImage("autotank1d.jpg", true));
			 image = image.shrinkBy(3);
			 image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX + m_iStartDrawPosX, m_iCurrentScreenY + m_iStartDrawPosY, m_iDrawWidth, m_iDrawHeight);
		 }
		 if (rivaldir == 1) {
			 image = (getEngine()->loadImage("autotank1l.jpg", true));
			 image = image.shrinkBy(3);
			 image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX + m_iStartDrawPosX, m_iCurrentScreenY + m_iStartDrawPosY, m_iDrawWidth, m_iDrawHeight);
		 }
		 if (rivaldir == 2) {
			 image = (getEngine()->loadImage("autotank1r.jpg", true));
			 image = image.shrinkBy(3);
			 image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX + m_iStartDrawPosX, m_iCurrentScreenY + m_iStartDrawPosY, m_iDrawWidth, m_iDrawHeight);
		 }
		 if (rivaldir == 3) {
			 image = (getEngine()->loadImage("autotank1.jpg", true));
			 image = image.shrinkBy(3);
			 image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX + m_iStartDrawPosX, m_iCurrentScreenY + m_iStartDrawPosY, m_iDrawWidth, m_iDrawHeight);
		 }
		
		
	 }	
}


 void AutoObject::setMove(int iStartTime, int iEndTime, int iCurrentTime,
	 int iStartX, int iStartY, int iEndX, int iEndY)
 {
	 move.setup(iStartX, iStartY, iEndX, iEndY, iStartTime, iEndTime);
	 
	/* move.calculate(iCurrentTime);
	 m_iCurrentScreenX = move.getX();

	 m_iCurrentScreenY = move.getY();
	 redrawDisplay();
*/

 }

