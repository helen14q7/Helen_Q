#pragma once
#include"StateEngine.h"
#include"GameState1.h"
#include"DrawingFilters.h"

class StateEngine;

class StartState :
	public StateEngine
{
public:
	StartState(Psyyq2Engine *pEngine);
	~StartState();
	void virKeyPress(int iKeyCode);
	void virInitial();
	void drawStringAbove();
private:
	GameState2 game2;
	GameState1 game1;
	Psyyq2Engine *pEngine;
	FilterPointsScaling m_filterScaling;
	FilterPointsTranslation m_filterTranslation;
public:
	//int virtInitialise();
	void virtMouseDown(int iButton, int iX, int iY);
	void virtMouseRoll(int x, int y, int which, int timestamp);
	void virtStateChange(int screen);
	void virtMouseMoved(int iX, int iY);
};

