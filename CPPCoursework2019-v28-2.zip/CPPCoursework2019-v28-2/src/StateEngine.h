#pragma once
//#include"Psyyq2Engine.h"
//#include"StartState.h"
class StateEngine
{
public:
	StateEngine();
	~StateEngine();
	virtual void virInitial();
	virtual void virKeyPress(int iKeyCode);
protected:
	
	//GameState1 level1;
	//StartState start;
public:
	virtual void drawStringAbove();
	virtual void drawStringUnder();
	virtual void InitialObject();
	
	virtual void virtStateChange(int screen);
	virtual void virtMouseDown(int iButton, int iX, int iY);
	virtual void virtMouseRoll(int x, int y, int which, int timestamp);
	virtual void virtMouseMoved(int iX, int iY);
	virtual  void appendObject(int dir);
};

