#pragma once
#include "StateEngine.h"
#include"Psyyq2Engine.h"

#include"ScoreState.h"
#include<vector>
#include<string>
#include<fstream>
#include<iostream>
#include<string.h>
class HighscoreState :
	public StateEngine
{
public:
	HighscoreState(Psyyq2Engine *pEngine);
	~HighscoreState();
private:
		//GameState2 game2;
		char name[200];
		//string name;
		char finalname[200];
		//string finalname;
		Psyyq2Engine* pEngine;
		ScoreState scorestate;
		int x;

		//string s;
		
public:
	
	
	void virKeyPress(int iKeyCode);
	
	void virInitial();
	void drawStringAbove();
	void virtStateChange(int screen);
};

