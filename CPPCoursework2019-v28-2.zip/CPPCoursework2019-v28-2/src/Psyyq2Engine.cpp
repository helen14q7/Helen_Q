#include"header.h"
#include "Psyyq2Engine.h"
#include"ControllingObject.h"
#include"StartState.h"
#include<vector>
#include<string>
#include<fstream>
#include<iostream>
#include<string.h>
using namespace std;

int score = 0;
int life = 5;
StartState *start;
Psyyq2Engine::Psyyq2Engine()
	:Co(NULL), po(NULL),tm(this)
		
{
	//set
	//StartState start(this);
	//start.InitialObject();
	//setState(&start);
	start = new StartState(this);
	state = start;
	if (state == NULL) {
		printf("yess\n");
		printf("the address of the start %p\n", &state);

	}
	//state->InitialObject();
	
}

Psyyq2Engine::~Psyyq2Engine()
{
	delete start;
}


void Psyyq2Engine::virtSetupBackgroundBuffer()
{

	//printf("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
	//fillBackground(0x000000);
	state->virInitial();
	

}




int Psyyq2Engine::virtInitialiseObjects()
{
	printf("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh2 set object\n");
	//printf("the address of the actual state is %p\n", state);
	state->InitialObject();
	//printf("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh3\n");
	return 0;
}


//void Psyyq2Engine::virtMouseDown(int iButton, int iX, int iY)
//{
//	//if (500<iY<550) {
//	//	Co->setPosition(iX, iY);
//	//}
//	
//	Co->setPosition(iX, Co->getDrawingRegionTop());
//}


void Psyyq2Engine::virtKeyDown(int iKeyCode)
{
	state->virKeyPress(iKeyCode);
}




void Psyyq2Engine::virtDrawStringsUnderneath()
{
	printf("hereeeeee uder\n");
	state->drawStringUnder();

}


void Psyyq2Engine::virtDrawStringsOnTop()
{

	state->drawStringAbove();

}


void Psyyq2Engine::virtMouseDown(int iButton, int iX, int iY)
{
	state->virtMouseDown(iButton, iX, iY);
}


void Psyyq2Engine::virtMouseWheel(int x, int y, int which, int timestamp)
{
	printf("rolling?\n");
	state->virtMouseRoll(x, y, which, timestamp);
}


void Psyyq2Engine::virtMouseMoved(int iX, int iY)
{
	state->virtMouseMoved(iX, iY);
}
void Psyyq2Engine::reStart() {
	setState(start);

}