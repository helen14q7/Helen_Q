#pragma once
#include "AutoObject.h"
#include"BaseEngine.h"
#include"MovementPosition.h"
#include"FloatObject.h"
#include"psyyq2TileManager.h"
#include"StateEngine.h"
#include"ControllingObject.h"

class PinObject :
	public AutoObject
{
public:
	
	PinObject(BaseEngine* pEngine, psyyq2TileManager* ptm,int iMapX, int iMapY,ControllingObject *Co,StateEngine *state);

	//void setMove(int iStartTime, int iEndTime, int iCurrentTime,
	//	int iStartX, int iStartY, int iEndX, int iEndY);
	~PinObject();

	
protected:
	//MovementPosition move;
	//FloatObject* flo;
	psyyq2TileManager* ptm;
	int autodir;
	int olddir = 1;
	int counter;
	int time = 0;
	int startTime = 0;
	int interval = 2000;
	StateEngine *state;
	ControllingObject* Co;
	int hitTime;
	
	//int iMapX;
	//int iMapY;
	
public:
	void virtDoUpdate(int iCurrentTime);
	int getPosX() {
		return m_iCurrentScreenX;
	}
	int getPosY() {
		return m_iCurrentScreenY;
	}
	
};


