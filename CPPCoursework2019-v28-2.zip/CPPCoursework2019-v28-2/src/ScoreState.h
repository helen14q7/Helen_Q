#pragma once
#include "StateEngine.h"
#include"Psyyq2Engine.h"
#include"OverState.h"
class ScoreState :
	public StateEngine
{
public:
	ScoreState(Psyyq2Engine* pEngine);
	~ScoreState();
private:
	Psyyq2Engine *pEngine;
	OverState over;
public:
	void virInitial();
	void drawStringAbove();
	void virKeyPress(int iKeyCode);
};

