#pragma once
#include "TileManager.h"

class psyyq2TileManager :
	public TileManager
{
public:
	SimpleImage image1;
	SimpleImage image2; 
	SimpleImage image3;
	SimpleImage image4;
	BaseEngine* pEngine;

public:
	psyyq2TileManager(BaseEngine* pEngine);
	~psyyq2TileManager();

	virtual void virtDrawTileAt(
		BaseEngine* pEngine,
		DrawingSurface* pSurface,
		int iMapX, int iMapY,
		int iStartPositionScreenX, int iStartPositionScreenY) const;
};