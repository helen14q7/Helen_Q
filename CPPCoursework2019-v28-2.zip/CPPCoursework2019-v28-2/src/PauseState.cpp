#include"header.h"
#include "PauseState.h"



PauseState::PauseState(Psyyq2Engine *pEngine, psyyq2TileManager *tm, StateEngine *state)
	:pEngine(pEngine), tm(tm), state(state)
{
}


PauseState::~PauseState()
{
}


void PauseState::virInitial()
{
 pEngine->fillBackground(0);
 tm->drawAllTiles(pEngine, pEngine->getBackgroundSurface());

}


void PauseState::drawStringAbove()
{
	printf("drawing the string?\n");
	pEngine->drawForegroundString(50, 200, "Paused. Press Space To Continue", 0x800000, NULL);
}


void PauseState::virKeyPress(int iKeyCode)
{
	switch (iKeyCode) {
	case SDLK_SPACE:
		pEngine->setState(state);

		pEngine->unpause();
		// Force redraw of background
		//pEngine->virtSetupBackgroundBuffer();
		// Redraw the whole screen now
		pEngine->redrawDisplay();
		break;

	}
}
