#include"header.h"
#include "PinObject.h"
#include"DisplayableObject.h"
//#include"DisplayableObjectContainer.h"
#include "CollisionDetection.h"
#include"BaseEngine.h"
#include"MovementPosition.h"
#include"TileManager.h"
#include"psyyq2TileManager.h"
//#include"ControllingObject.h"

extern int life;
extern int score;
int rival = 2;
//int rivaldir = 0;//down


PinObject::PinObject(BaseEngine* pEngine, psyyq2TileManager* ptm, int iMapX, int iMapY,ControllingObject *Co,StateEngine *state)
	: AutoObject(pEngine, iMapX, iMapY), ptm(ptm),Co(Co),state(state)
{
	autodir = 1;
	olddir = 0;
	counter = 0;
	hitTime = 0;
}

PinObject::~PinObject()
{
}


void PinObject::virtDoUpdate(int iCurrentTime) {
	if (!isVisible()) {
		m_iCurrentScreenX = -50;
		m_iCurrentScreenY = -50;
		redrawDisplay();
		return;
	}
	if (getEngine()->isPaused()) {
		return;
	}
	DisplayableObject* pObject;
		pObject = m_pEngine->getDisplayableObject(0);
		if (CollisionDetection::checkRectangles(getDrawingRegionLeft(), getDrawingRegionRight(), getDrawingRegionTop(), getDrawingRegionBottom(), pObject->getDrawingRegionLeft(), pObject->getDrawingRegionRight(), pObject->getDrawingRegionTop(), pObject->getDrawingRegionBottom())) {
	
			if (m_pEngine->getModifiedTime() - hitTime >= 2000) {


				score = score - 20;
				life = life - 1;
				printf("the pin the life is %d\n", life);
				hitTime = m_pEngine->getModifiedTime();
			}
			if (life == 0) {
				
				setVisible(false);
				m_pEngine->setAllObjectsVisible(false);
				state->virtStateChange(1);
			}
			
			
	
	}
		
	
		
	
	printf("update the pin\n");

	if (move.hasMovementFinished(iCurrentTime))
	{
		printf("finishhere\n");




//		if (abs((autodir + 1) % 3 - (olddir + 1)%3 )== 2)
//		{
//			counter = 1;
//			time = iCurrentTime;
//		    olddir = autodir;
//			
//		}
//		//olddir = autodir;
//		switch (rand() % 5)
//		{
//		case 0: //increase by 1 
//			autodir = (autodir + 1) % 3;
//			break;
//		case 1: //decrease by 1
//			autodir = (autodir + 2) % 3;
//			break;
//		}
//
//
//
//		while ( abs((autodir + 1) % 3 - (olddir + 1)%3) == 2 &&iCurrentTime-time<2000&&counter==1) {
//
//			switch (rand() % 5)
//			{
//			case 0: //increase by 1 
//				autodir = (autodir + 1) % 3;
//				break;
//			case 1: //decrease by 1
//				autodir = (autodir + 2) % 3;
//				break;
//			case 2:
//				autodir = 0;
//				break;
//			}
//
//		}
//		counter = 0;
//		int olddir = autodir;
//		int x, y;
//		switch (autodir % 3) {
//		case 0: x = 0; rivaldir=0; break;//down
//		case 1: x = -1; rivaldir = 1; break;///left
//		case 2: x = 1; rivaldir = 2; break;//right
//		//case 3: x = 0; break;//up
//		}
//		switch (autodir % 3) {
//		case 0: y = 1; break;//down
//		case 1:y = 0; break;//left
//		case 2: y = 0; break;//right
//		//case 3: y = -1; break;//up
//		}
//
//		/*if ((getEngine()->getModifiedTime()) - startTime >= interval) {
//		
//			startTime = getEngine()->getModifiedTime();
//			state->appendObject(rivaldir);
//		}
//*/
//		
//		//switch (ptm->getMapValue(iMapX + x, iMapY + y)) {
//		//case 1:
//		//	case
//		//}
//		printf("long long after\n");
		int x = 0;
		int y = 0;
		int access = 0;
		int test = 0;
		int pre = 0;
		printf("before compa\n");
		if (m_iCurrentScreenY -Co->getPosY()>=50) {//the player is above//go up
			y = -1;
			x = 0;
			test = 1;
			pre = 3;
			printf("up\n");
		}
		if (Co->getPosY()-m_iCurrentScreenY >=50) {//the player is below//go down
			y =  1;
			x = 0;
			test = 1;
			pre = 0;
			printf("down\n");
		}
		printf("iMapX is %d, iMapY is %d\n",iMapX,iMapY);
		printf("the map hightth is %d\n", ptm->getMapHeight());
		printf("before compa x\n");
		if (ptm->getMapValue(iMapX + x, iMapY + y) == 0&&test==1) {

			iMapX = iMapX + x;
			iMapY = iMapY + y;
			printf("set move part of pin\n");
			//setMove(iCurrentTime, iCurrentTime + 400 + rand() % 300, iCurrentTime, m_iCurrentScreenX, m_iCurrentScreenY, iMapX * 50 + 5, iMapY * 50 + 5);
			printf("after set the move of pin\n");
			access = 1;
			rivaldir = pre;
			}
		if (access != 1) {
			if (m_iCurrentScreenX > Co->getPosX()) {//user on the left
				x = - 1;
				y = 0;
				test = 1;
				pre = 1;
				printf("left\n");
			}
			if (m_iCurrentScreenX < Co->getPosX()) {//user on the left
				x =  1;
				y = 0;
				test = 1;
				pre = 2;
				printf("right\n");
			}
			if (ptm->getMapValue(iMapX + x, iMapY + y) == 0 && test == 1) {

				iMapX = iMapX + x;
				iMapY = iMapY + y;
				printf("set move part of pin\n");
				
				printf("after set the move of pin\n");
				access = 1;
				rivaldir = pre;
			}

		}
			

		
		
		
		if (iMapX <= 0 && x == -1) {
			x = 1;
			iMapX = 0;
		}
		if (iMapY <= 0 && y == -1) {
			y = 1;
			iMapY = 0;

		}
		if (iMapX >= ptm->getMapWidth()-1 && x == 1) {

			x = -1;
			iMapX = ptm->getMapWidth() - 1;

		}
		if (iMapY >= ptm->getMapHeight()-1&& y == 1) {

			y = -1;
			iMapY = ptm->getMapHeight() - 1;

		}
		if (access == 1) {
			setMove(iCurrentTime, iCurrentTime + 400 + rand() % 300, iCurrentTime, m_iCurrentScreenX, m_iCurrentScreenY, iMapX * 50 + 5, iMapY * 50 + 5);
			printf("reset: %d,%d\n",iMapX,iMapY);
			redrawDisplay();

			//access = 0;
		}
		if (access == 0) {
			switch (autodir % 4) {
					case 0: x = 0; rivaldir=0; break;//down
					case 1: x = -1; rivaldir = 1; break;///left
				    case 2: x = 1; rivaldir = 2; break;//right
					case 3: x = 0; rivaldir = 3; break;//up
						}
			switch (autodir % 4) {
						case 0: y = 1; break;//down
						case 1:y = 0; break;//left
						case 2: y = 0; break;//right
						case 3: y = -1; break;//up
						}
			if (ptm->getMapValue(iMapX + x, iMapY + y) == 0) {

				iMapX = iMapX + x;
				iMapY = iMapY + y;
				printf("set move part of pin\n");
				setMove(iCurrentTime, iCurrentTime + 400 + rand() % 300, iCurrentTime, m_iCurrentScreenX, m_iCurrentScreenY, iMapX * 50 + 5, iMapY * 50 + 5);
				printf("after set the move of pin\n");
				access = 1;
			}
		}
	
	}

	
	if(!(move.hasMovementFinished(iCurrentTime))){
		move.calculate(iCurrentTime);
		m_iCurrentScreenX = move.getX();
		m_iCurrentScreenY = move.getY();
		DisplayableObject* pObject;
		pObject = m_pEngine->getDisplayableObject(0);
		/*if (CollisionDetection::checkRectangles(getDrawingRegionLeft(), getDrawingRegionRight(), getDrawingRegionTop(), getDrawingRegionBottom(), pObject->getDrawingRegionLeft(), pObject->getDrawingRegionRight(), pObject->getDrawingRegionTop(), pObject->getDrawingRegionBottom())) {


			score = score - 20;
			life = life - 1;
			printf("the pin the life is %d\n", life);
			if (life == 0) {

				setVisible(false);
				m_pEngine->setAllObjectsVisible(false);
				state->virtStateChange(1);
			}



		}*/


	}
	//image= (getEngine()->loadImage("autotank.jpg", true));
	redrawDisplay();
	
}

			
		//switch()





//void PinObject::setMove(int iStartTime, int iEndTime, int iCurrentTime,
	//int iStartX, int iStartY, int iEndX, int iEndY)
//{
//	move.setup(iStartX, iStartY, iEndX, iEndY, iStartTime, iEndTime);
	//move.calculate(iCurrentTime);
	//move.calculate(iCurrentTime);
	//m_iCurrentScreenX = move.getX();
	//m_iCurrentScreenY = move.getY();


//}



//void PinObject::virtDoUpdate(int iCurrentTime)
//{
//if (!isVisible()) {
//
//
//		//printf("HIIIIIIIIIIIIIIIIIIIIIII!!!!!");
//		m_iCurrentScreenX = -50;
//		m_iCurrentScreenY = -50;
//		move.reverse();
//		move.reverse();
//		setVisible(true);
//		//reverse reverse didnot change the current position so change the current position first
//		redrawDisplay();
////		
//		
//			
////			
//		return;
//	}
//		
//	//flo = new FloatObject(m_pEngine, 20);
//	//appendObjectToArray(flo);
//	move.calculate(iCurrentTime);
//	m_iCurrentScreenX = move.getX();
//	
//	m_iCurrentScreenY = move.getY();
//	redrawDisplay();
//	//printf("gethereeeeeeeeeeeeeeeeeeeeeeeeeeeee %d", move.getX());
//	if(move.hasMovementFinished(iCurrentTime))
//	{
//		//setVisible(true);
//		move.reverse();
//		move.reverse();
//		
//		
//
//	}
//
//	DisplayableObject* pObject;
//	pObject = m_pEngine->getDisplayableObject(0);
//	if (CollisionDetection::checkRectangles(getDrawingRegionLeft(), getDrawingRegionRight(), getDrawingRegionTop(), getDrawingRegionBottom(), pObject->getDrawingRegionLeft(), pObject->getDrawingRegionRight(), pObject->getDrawingRegionTop(), pObject->getDrawingRegionBottom())) {
//
//		//printf("2222222222222222222c");
//		score = score -20;
//		life = life - 1;
//		if (life == 0) {
//			m_pEngine->setExitWithCode(0);
//		}
//		setVisible(false);
//		pObject->setVisible(false);
//
//	}
//		
//
//
//
//
//	redrawDisplay();
//
//}
