#include"header.h"
#include "GameState1.h"
#include"ControllingObject.h"
#include<vector>
#include<string>
#include<fstream>
#include<iostream>
#include<string.h>
#include <map>
#include <functional>

using namespace std;
extern int life;
extern int score;
extern int dir;
//extern int rivaldir;
//vector<int> highscores;
map<int, string, std::greater<int>> highscores;
int level = 1;
GameState1::GameState1(Psyyq2Engine *pEngine)
	:pEngine(pEngine),game2(pEngine),pass1(pEngine),scorestate(pEngine), scorestate2(pEngine),tm(pEngine)
{
	startTime = pEngine->getModifiedTime();
	startTime2 = pEngine->getModifiedTime();
}


GameState1::~GameState1()
{
	if (pause != NULL) {
		delete pause;
	}
	

}


void GameState1::virInitial()
{
	pEngine->fillBackground(0x000000);
	ifstream mapfile;
	vector<string> line;
	mapfile.open("map.txt");
	string inputline;
	int maphight = 12;
	int maplength = 16;
	if (mapfile.is_open()) {
		getline(mapfile, inputline);
		while (mapfile) {
			line.push_back(inputline);
			cout << inputline << endl;
			getline(mapfile, inputline);

		}
	}
	else {
		cerr << "Unable to open file !" << endl;
		return;
	}
	cout << maphight << endl;
	cout << maplength << endl;
	tm.setMapSize(maplength, maphight);
	for (int x = 0; x < maplength; x++) {
		cout << "xx" << x << endl;
		for (int y = 0; y < maphight; y++) {


			cout << "x " << x << "y " << y << endl;
			tm.setMapValue(x, y, line[y][x] - 'a');
		}
	}

	for (int y = 0; y < maphight; y++)
	{
		for (int x = 0; x < maplength; x++)
			printf("%d ", tm.getMapValue(x, y));
		printf("\n");
	}






	tm.setTopLeftPositionOnScreen(0, 0);

	tm.drawAllTiles(pEngine, pEngine->getBackgroundSurface());
}




void GameState1::virKeyPress(int iKeyCode)
{

	switch (iKeyCode) {
	case SDLK_SPACE:
		sho = new ShootingObject(pEngine,&tm,this,0);
		//printf("the dir is %d\n", dir);
		switch (dir) {
		case 0:
			sho->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), Co->getPosX() + 20, Co->getPosY() + 20, Co->getPosX() + 20, Co->getPosY() - 600);
			printf("up\n");
			break;
		case 1:
			sho->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), Co->getPosX() + 20, Co->getPosY() + 20, Co->getPosX() -800, Co->getPosY() +20);
			printf("left\n");
			break;
		case 2:
			sho->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), Co->getPosX() + 20, Co->getPosY() + 20, Co->getPosX() +800, Co->getPosY() +20);
			printf("right\n");
			break;
		case 3:
			sho->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), Co->getPosX() + 20, Co->getPosY() + 20, Co->getPosX() + 20, Co->getPosY() + 600);
			printf("down\n");
			break;
		}
		//sho->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), Co->getPosX() + 20, Co->getPosY()+20, Co->getPosX() + 25, Co->getPosY() - 600);
		pEngine->appendObjectToArray(sho);
		//pEngine->redrawDisplay();
		
		break;
	case SDLK_ESCAPE:
		virtStateChange(1);
		level = 0;
		break;
	case SDLK_p:
		
		virtStateChange(3);
		break;
		//pEngine->pause();


	}
}




void GameState1::drawStringAbove()
{
	char buf[128];
	sprintf(buf, "Time %6d", pEngine->getModifiedTime() / 1000);
	pEngine->drawForegroundString(30, 10, buf, 0xD2691E, NULL);
	char buff[128];
	sprintf(buff, "Score %6d", score);
	pEngine->drawForegroundString(230, 10, buff, 0xD2691E, NULL);
	char buff1[128];
	sprintf(buff1, "Life %6d", life);
	pEngine->drawForegroundString(460, 10, buff1, 0xD2691E, NULL);
}


void GameState1::drawStringUnder()
{
	pEngine->drawBackgroundString(650, 10, "The Tank", 0xD2691E, NULL);
	if (pEngine->getModifiedTime() - startTime >= 2000)
	{
		if (po->isVisible()) {


			startTime = pEngine->getModifiedTime();
			appendObject(po->getrivaldir());
		}
		
	}
	if (pEngine->getModifiedTime() - startTime2 >= 3000)
	{
		if (po1->isVisible()) {


			startTime2 = pEngine->getModifiedTime();
			appendObject2(po1->getrivaldir());
		}

	}
}


void GameState1::InitialObject()
{

	Co = new ControllingObject(pEngine, &tm);

	po = new PinObject(pEngine, &tm, 3, 0,Co,this);
	po1 = new PinObject(pEngine, &tm, 11, 0, Co,this);
	

	pEngine->drawableObjectsChanged();
	pEngine->destroyOldObjects(true);
	pEngine->createObjectArray(20);

	pEngine->storeObjectInArray(0, Co);
	pEngine->storeObjectInArray(1, po);
	pEngine->storeObjectInArray(2, po1);
	//storeObjectInArray(2, po1);
	//storeObjectInArray(2, po1);
	//	storeObjectInArray(3, po2);
	//	storeObjectInArray(4, fo1);
		///////storeObjectInArray(5, po4);
		///////////..//reObjectInArray(6, po5);
	//	storeObjectInArray(5, po6);
		////////storeObjectInArray(8, po7);
	//	storeObjectInArray(6, fo);
	//	storeObjectInArray(7, fo2);
	pEngine->setAllObjectsVisible(true);
	//tm.drawAllTiles(pEngine, pEngine->getBackgroundSurface());

}


void GameState1::virtStateChange(int screen)
{

	
		//highscores.push_back(score);
	printf("state change of game1\n");
	printf("the size is %d\n", highscores.size());
	if (screen==1) {
		highscores.insert({ score,"ANONYMOUS" });
		if (highscores.size() <= 5) {
			printf("the first five score is %d\n", score);
			screen = 2;
			printf("the size is %d after\n", highscores.size());

		}
		else if (score > prev(highscores.end())->first) {
			printf("the new high score is %d\n", score);
			screen = 2;

		}

		if (highscores.size() > 5) {
			//highscores.pop_back();
			highscores.erase(prev(highscores.end()));
		}
	}

		switch (screen) {
		case 0:
			pEngine->setState(&pass1);

			pEngine->virtInitialise();
			//pEngine->virtInitialise()
			//printf("hreee222222222\n");
			pEngine->redrawDisplay();
			break;
		case 1: //just high score;
			pEngine->setAllObjectsVisible(false);
			
			pEngine->setState(&scorestate2);
			pEngine->virtInitialise();
			//pEngine->virtInitialise()
			//printf("hreee222222222\n");
			pEngine->redrawDisplay();

		
			
			break;
		case 2:
			pEngine->setAllObjectsVisible(false);
			pEngine->setState(&scorestate);
			pEngine->virtInitialise();
			//pEngine->virtInitialise()
			//printf("hreee222222222\n");
			pEngine->redrawDisplay();
			break;
		case 3:
			pEngine->pause();
			pause = new PauseState(pEngine, &tm, this);
			pEngine->setState(pause);
			
			pEngine->virtInitialise();
			printf("after ini\n");
			pEngine->redrawDisplay();
			break;



		}
		


	
	// 
	
}


void GameState1::appendObject(int dir)
{
	printf("the direction is %d\n", dir);
	sho1 = new ShootingObject(pEngine, &tm, this,1);
	switch (dir) {
	case 0://down
		//sho->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), Co->getPosX() + 20, Co->getPosY() + 20, Co->getPosX() + 20, Co->getPosY() - 600);
		sho1->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), po->getPosX() + 20, po->getPosY() + 20, po->getPosX() + 20, po->getPosY() + 600);
		printf("down\n");
		break;
	case 1:
		sho1->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), po->getPosX() + 20, po->getPosY() + 20, po->getPosX() - 800, po->getPosY() + 20);
		printf("left\n");
		break;
	case 2:
		sho1->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), po->getPosX() + 20, po->getPosY() + 20, po->getPosX() + 800, po->getPosY() + 20);
		printf("right\n");
		break;
	case 3:
		sho1->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), po->getPosX() + 20, po->getPosY() + 20, po->getPosX() + 20, po->getPosY() - 600);
		printf("up\n");
		break;
	}
	printf("out?\n");
	pEngine->appendObjectToArray(sho1);
	printf("final?\n");
	printf("sho1 is %p\n", sho1);
		
}


void GameState1::virtMouseMoved(int iX, int iY)
{
	
}


void GameState1::appendObject2(int dir)
{
	//printf("the direction is %d\n", dir);
	sho2 = new ShootingObject(pEngine, &tm, this, 1);
	switch (dir) {
	case 0://down
		//sho->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), Co->getPosX() + 20, Co->getPosY() + 20, Co->getPosX() + 20, Co->getPosY() - 600);
		sho2->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), po1->getPosX() + 20, po1->getPosY() + 20, po1->getPosX() + 20, po1->getPosY() + 600);
		printf("down\n");
		break;
	case 1:
		sho2->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), po1->getPosX() + 20, po1->getPosY() + 20, po1->getPosX() - 800, po1->getPosY() + 20);
		printf("left\n");
		break;
	case 2:
		sho2->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), po1->getPosX() + 20, po1->getPosY() + 20, po1->getPosX() + 800, po1->getPosY() + 20);
		printf("right\n");
		break;
	case 3:
		sho2->setMove(pEngine->getModifiedTime(), pEngine->getModifiedTime() + 800, pEngine->getModifiedTime(), po1->getPosX() + 20, po1->getPosY() + 20, po1->getPosX() + 20, po1->getPosY() - 600);
		printf("up\n");
		break;
	}
	printf("out?\n");
	pEngine->appendObjectToArray(sho2);
	printf("final?\n");
	printf("sho1 is %p\n", sho1);

}
