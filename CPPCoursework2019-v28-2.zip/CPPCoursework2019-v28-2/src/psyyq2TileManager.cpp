#include"header.h"
#include "psyyq2TileManager.h"
#include"TileManager.h"
#include"BaseEngine.h"



psyyq2TileManager::psyyq2TileManager(BaseEngine* pEngine)
	: pEngine(pEngine),TileManager(50, 50),image1(pEngine->loadImage("brickwall1.jpg", true)),image2(pEngine->loadImage("marble1.jpg", true)),image3(pEngine->loadImage("heart.png", true)),image4(pEngine->loadImage("heartwall.jpg", true))
{
	image1= image1.shrinkBy(4);
	image2 = image2.shrinkBy(4);
	image3 = image3.shrinkBy(7);
	image4 = image4.shrinkBy(4);
	
}


psyyq2TileManager::~psyyq2TileManager()
{
}


void psyyq2TileManager::virtDrawTileAt(BaseEngine* pEngine, DrawingSurface*pSurface, int iMapX, int iMapY, int iStartPositionScreenX, int iStartPositionScreenY)const
{
	//SimpleImage image1;
	unsigned int iColour;
	int iMapValue = getMapValue(iMapX, iMapY);
	if (iMapValue == 1) {
		//iColour = 0x4B0082;
		//image1 = (pEngine->loadImage("brickwall1.jpg", true));
		//image1 = image1.shrinkBy(4);
		image1.renderImageWithMask(pSurface, 0, 0,iStartPositionScreenX, iStartPositionScreenY, 50, 50);
	}
	if (iMapValue == 0) {
		pSurface->drawRectangle(
				iStartPositionScreenX,
				iStartPositionScreenY,
				iStartPositionScreenX + getTileWidth() - 1,
				iStartPositionScreenY + getTileHeight() - 1,
				0x000000);
		//image1 = (pEngine->loadImage("black.jpg", true));
		//image1.renderImageWithMask(pSurface, 0, 0, iStartPositionScreenX, iStartPositionScreenY, 50, 50);
	
		
	}
	if (iMapValue == 2) {
		//iColour = 0xFFF0F5;
		//image1 = (pEngine->loadImage("marble1.jpg", true));
		//image1 = image1.shrinkBy(4);
		image2.renderImageWithMask(pSurface, 0, 0, iStartPositionScreenX, iStartPositionScreenY, 50, 50);
	}
	if (iMapValue == 3) {
		pSurface->drawRectangle(
			iStartPositionScreenX,
			iStartPositionScreenY,
			iStartPositionScreenX + getTileWidth() - 1,
			iStartPositionScreenY + getTileHeight() - 1,
			0x000000);
		//image1 = (pEngine->loadImage("heart.png", true));
		//image1=image1.shrinkBy(7);
		image3.renderImageWithMask(pSurface, 0, 0, iStartPositionScreenX, iStartPositionScreenY, 50, 50);

	}
	if (iMapValue == 4) {
		//image1 = (pEngine->loadImage("heartwall.jpg", true));
		//image1 = image1.shrinkBy(4);
		image4.renderImageWithMask(pSurface, 0, 0, iStartPositionScreenX, iStartPositionScreenY, 50, 50);

	}

	//pSurface->drawRectangle(
	//pSurface->drawOval(
	//	iStartPositionScreenX,
	//	iStartPositionScreenY,
	//	iStartPositionScreenX + getTileWidth() - 1,
	//	iStartPositionScreenY + getTileHeight() - 1,
	//	iColour);
}




