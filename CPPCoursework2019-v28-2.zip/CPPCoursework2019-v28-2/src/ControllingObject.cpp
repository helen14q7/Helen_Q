#include"header.h"
#include "DisplayableObject.h"
#include"BaseEngine.h"
#include "ControllingObject.h"
#include"psyyq2TileManager.h"
#include"TileManager.h"
#include"CollisionDetection.h"


int dir = 0;
extern int life;
extern int score;
//ControllingObject::ControllingObject(BaseEngine* pEngine, psyyq2TileManager* ptm)
//	: DisplayableObject(365, 500, pEngine, 70, 68, true), ptm(ptm)
//{
//	
//}
ControllingObject::ControllingObject(BaseEngine* pEngine, psyyq2TileManager* ptm)
	: DisplayableObject(14*50,11*50,pEngine, 40, 40, true), ptm(ptm){

	
}


	//image = image.shrinkBy(1);



ControllingObject::~ControllingObject()
{
}





void ControllingObject::virtDraw()
{
	SimpleImage image;

	if (dir == 0) {
		image = (getEngine()->loadImage("tankn.jpg", true));
		image = image.shrinkBy(5);
	
		image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX + m_iStartDrawPosX, m_iCurrentScreenY + m_iStartDrawPosY, m_iDrawWidth, m_iDrawHeight);
	}
	if (dir == 1) {
		image = (getEngine()->loadImage("tanknleft.jpg", true));
		image = image.shrinkBy(5);

		image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX + m_iStartDrawPosX, m_iCurrentScreenY + m_iStartDrawPosY, m_iDrawWidth, m_iDrawHeight);
	}
	if (dir == 2) {
		image = (getEngine()->loadImage("tanknright.jpg", true));
		image = image.shrinkBy(5);

		image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX + m_iStartDrawPosX, m_iCurrentScreenY + m_iStartDrawPosY, m_iDrawWidth, m_iDrawHeight);
	}
	if (dir == 3) {
		image = (getEngine()->loadImage("tankndown.jpg", true));
		image = image.shrinkBy(5);

		image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX + m_iStartDrawPosX, m_iCurrentScreenY + m_iStartDrawPosY, m_iDrawWidth, m_iDrawHeight);
	}
	//image.renderImageWithMask(getEngine()->getForegroundSurface(), 0, 0, m_iCurrentScreenX , m_iCurrentScreenY, m_iDrawWidth, m_iDrawHeight);

}


void ControllingObject::virtDoUpdate(int iCurrentTime)
{
	if (getEngine()->isPaused())
	{
		return;
	}
	if (!isVisible())
	{
		m_iCurrentScreenX = -50;
		m_iCurrentScreenY = -50;
		redrawDisplay();
		return;

	}
	int move = 0;
	int back = 0;
	if (getEngine()->isKeyPressed(SDLK_LEFT))
	{
		int cur;
		cur = m_iCurrentScreenX;
		cur -= 1;
		for (int y = 0; y < ptm->getMapHeight(); y++) {
			for (int x = 0; x<ptm->getMapWidth(); x++) {
				//if (CollisionDetection::checkRectangles(cur, cur + 25, m_iCurrentScreenY, m_iCurrentScreenY + 25, x * 50, x * 50 + 50, y * 50, y * 50 + 50))
				if(!((cur+40<=x*50)||(x*50+50<=cur)||(m_iCurrentScreenY+40<=y*50)||(y*50+50<=m_iCurrentScreenY)))
				{
					

					if (ptm->getMapValue(x, y) == 3)
					{
						score = score + 50;
						life = life + 1;
						ptm->setAndRedrawMapValueAt(x, y, 0, m_pEngine, m_pEngine->getBackgroundSurface());

					}


					else if (ptm->getMapValue(x, y) != 0)
					{

						redrawDisplay();
						return;
					}
					
				}

			}
		}
		m_iCurrentScreenX -= 1;
		move = 1;
		dir = 1;

		
	
	}
	if (getEngine()->isKeyPressed(SDLK_RIGHT)) {
		//iMapX = iMapX + 1;
		int cur;
		cur = m_iCurrentScreenX;
		cur +=1;
		for (int y = 0; y < ptm->getMapHeight(); y++) {
			for (int x = 0; x < ptm->getMapWidth(); x++) {
				if (!((cur + 40 <= x * 50) || (x * 50 + 50 <= cur) || (m_iCurrentScreenY + 40 <= y * 50) || (y * 50 + 50 <= m_iCurrentScreenY)))
				{

					if (ptm->getMapValue(x, y) == 3)
					{
						score = score + 50;
						life = life + 1;
						ptm->setAndRedrawMapValueAt(x, y, 0, m_pEngine, m_pEngine->getBackgroundSurface());
						
					}


					else if (ptm->getMapValue(x, y) != 0)
					{

						redrawDisplay();
						return;
					}

				}

			}
		}
			m_iCurrentScreenX += 1;
			move = 1;
			back = 1;
			dir = 2;
		
	
		
	}
	if (getEngine()->isKeyPressed(SDLK_UP)) {
		int cur;
		cur = m_iCurrentScreenY;
		cur -= 1;
		for (int y = 0; y < ptm->getMapHeight(); y++) {
			for (int x = 0; x < ptm->getMapWidth(); x++) {
				if (!((m_iCurrentScreenX + 40 <= x * 50) || (x * 50 + 50 <= m_iCurrentScreenX) || (cur + 40 <= y * 50) || (y * 50 + 50 <= cur)))
				{


					if (ptm->getMapValue(x, y) == 3)
					{
						score = score + 50;
						life = life + 1;
						ptm->setAndRedrawMapValueAt(x, y, 0, m_pEngine, m_pEngine->getBackgroundSurface());

					}


					else if (ptm->getMapValue(x, y) != 0)
					{

						redrawDisplay();
						return;
					}
				}
			}
		}
			m_iCurrentScreenY -= 1;
			move = 1;
			back = 1;
			dir = 0;
		
		
	}
	if (getEngine()->isKeyPressed(SDLK_DOWN)) {
		int cur;
		cur = m_iCurrentScreenY;
		cur += 1;
		for (int y = 0; y < ptm->getMapHeight(); y++) {
			for (int x = 0; x < ptm->getMapWidth(); x++) {
				if (!((m_iCurrentScreenX + 40 <= x * 50) || (x * 50 + 50 <= m_iCurrentScreenX) || (cur + 40 <= y * 50) || (y * 50 + 50 <= cur)))
				{


					if (ptm->getMapValue(x, y) == 3)
					{
						score = score + 50;
						life = life + 1;
						ptm->setAndRedrawMapValueAt(x, y, 0, m_pEngine, m_pEngine->getBackgroundSurface());

					}


					else if (ptm->getMapValue(x, y) != 0)
					{

						redrawDisplay();
						return;
					}

				}

			}
		}
		m_iCurrentScreenY += 1;
		move = 1;
		back = 1;
		dir = 3;
		
		
	}
	
	




		//m_iCurrentScreenX += 15;
	if (m_iCurrentScreenX < 0)
		m_iCurrentScreenX = 0;
	if (m_iCurrentScreenY < 0)
		m_iCurrentScreenY = 0;
	if (m_iCurrentScreenX >= getEngine()->getWindowWidth() - m_iDrawWidth)
		m_iCurrentScreenX = getEngine()->getWindowWidth() - m_iDrawWidth;
	if (m_iCurrentScreenY >= getEngine()->getWindowHeight() - m_iDrawHeight)
		m_iCurrentScreenY = getEngine()->getWindowHeight() - m_iDrawHeight;

	redrawDisplay();
	
	

	
}




int ControllingObject::getPosX()
{
	
	return m_iCurrentScreenX;
}


int ControllingObject::getPosY()
{
	
	return m_iCurrentScreenY;
}
