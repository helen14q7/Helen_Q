#pragma once
#include "BaseEngine.h"
#include"ControllingObject.h"
#include"psyyq2TileManager.h"
#include"PinObject.h"
#include"FloatObject.h"
#include"ShootingObject.h"
#include"StateEngine.h"
//#include"StartState.h"
class BouncingBall;
class Psyyq2Engine :
	public BaseEngine
{
public:
	Psyyq2Engine();
	
	
	~Psyyq2Engine();
	void virtSetupBackgroundBuffer();

	int virtInitialiseObjects();
	//void virtMouseDown(int iButton, int iX, int iY);

private:
	ControllingObject* Co;
	psyyq2TileManager tm;
	PinObject *po;
	PinObject *po1;
	PinObject *po2;
	//PinObject *po3;
	//PinObject *po4;
	//PinObject *po5;
	PinObject *po6;
	//PinObject *po7;
	ShootingObject *sho;
	FloatObject *fo;
	FloatObject *fo1;
	FloatObject *fo2;
    StateEngine *state = NULL;
	//StartState *start;
	//StartState start;

	
	
public:
	void virtKeyDown(int iKeyCode);
	//void Notify(int iCurrentTime);
	void virtDrawStringsUnderneath();
	void virtDrawStringsOnTop();
	//StartState start;
	//StateEngine *state = &start;
	void setState(StateEngine *state1) {
		printf("setState in psyyq2\n");
		state = state1;
		/*if (state == NULL) {
			printf("HELLLYEAH\n");
		}
		else {
			printf("the address of state is %p\n", state);
			printf("the adrres of the start is %p\n", state1);
			
		}*/
	}
	
	void reStart();
	void virtMouseDown(int iButton, int iX, int iY);
	void virtMouseWheel(int x, int y, int which, int timestamp);
	void virtMouseMoved(int iX, int iY);
};

