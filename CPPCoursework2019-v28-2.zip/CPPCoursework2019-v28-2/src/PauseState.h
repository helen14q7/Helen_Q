#pragma once
#include "StateEngine.h"
#include"Psyyq2Engine.h"
#include"psyyq2TileManager.h"

class PauseState :
	public StateEngine
{
public:
	PauseState(Psyyq2Engine *pEngine,psyyq2TileManager *tm,StateEngine *state);
	~PauseState();
	void virInitial();
private:
	Psyyq2Engine *pEngine;
	psyyq2TileManager *tm;
	StateEngine *state;
public:
	void drawStringAbove();
	void virKeyPress(int iKeyCode);
};

