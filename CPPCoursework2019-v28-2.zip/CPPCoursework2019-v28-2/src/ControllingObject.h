#pragma once
#include "DisplayableObject.h"
#include"psyyq2TileManager.h"
class psyyq2TileManager;
class ControllingObject :
	public DisplayableObject
{
public:
	ControllingObject(BaseEngine* pEngine, psyyq2TileManager* ptm);
	//ControllingObject(BaseEngine* pEngine, psyyq2TileManager* ptm, std::string strURL);
	~ControllingObject();
	
	void virtDraw();
	void virtDoUpdate(int iCurrentTime);
protected:
	psyyq2TileManager* ptm;
	

public:
	int getPosX();
	int getPosY();
	int iMapX1;
	int iMapX2;
	int iMapY1;
	int iMapY2;
//private:
	//SimpleImage image;
};

