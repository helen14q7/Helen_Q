#include"header.h"
#include "HighscoreState.h"


extern map<int, string, std::greater<int>> highscores;
extern int score;
int enternum = 0;
int ikey = 0;
HighscoreState::HighscoreState(Psyyq2Engine *pEngine)
	: pEngine(pEngine), x(0),scorestate(pEngine)
{
	sprintf(finalname, "");
	sprintf(name, "");

}


HighscoreState::~HighscoreState()
{
}







void HighscoreState::virKeyPress(int iKeyCode)
{
	

	if (iKeyCode == SDLK_RETURN) {
		if (x != 0) {
			highscores[score] = finalname;
		}
		
		virtStateChange(0);


	}
	if ((iKeyCode == SDLK_BACKSPACE)&&enternum!=0){
		
		if (enternum == 1) {
			sprintf(name, "");
			sprintf(finalname, "");
			pEngine->redrawDisplay();
			x = 0;
			enternum = 0;
		}
		else
		{
			enternum--;
			finalname[enternum] = '\0';
			printf("hhhhhererere\n");

			sprintf(name, "%s", finalname);

			pEngine->redrawDisplay();
		}
		//enternum++;
	}
	else if(iKeyCode>='A'&&iKeyCode<='z'){
		//printf("before writing??????\n");
		
	//	printf("the ikeycode is %d  %c\n", iKeyCode);
		ikey = iKeyCode;
		sprintf(name, "%s%c",finalname,iKeyCode);
		
		
		
		strcpy(finalname, name);
		//printf("the name is %s\n",name);
		x = 1;
	//	printf("the x changes here\n");
		
		//highscores[score] = finalname;
		//printf("after the name is %s\n", name);
		//pEngine->drawForegroundString(30, 400, name, 0xD2691E, NULL);
		pEngine->redrawDisplay();
		enternum++;

	}
}




void HighscoreState::virInitial()
{
	pEngine->fillBackground(0x000000);

}


void HighscoreState::drawStringAbove()
{
	pEngine->drawForegroundString(100, 300, "The Name", 0xD2691E, NULL);
	if (ikey == 13) {
		sprintf(finalname, "");
		sprintf(name, "");
		return;

	}
	if (x!= 0) {
		printf("is x ==1?\n");
		printf("draw name %s\n",name);
		printf("the iKeyCode is %d\n", ikey);
		pEngine->drawForegroundString(300, 300, name, 0xD2691E, NULL);
		printf("drawnameafter\n");
		//sprintf(name, "");
	}
	
}


void HighscoreState::virtStateChange(int screen)
{
	x = 0;
	enternum = 0;
	sprintf(finalname, "");
	sprintf(name, "");
	ofstream inputfile;
	inputfile.open("highscores.txt");
	for (const auto &i : highscores) {
		inputfile << i.first <<"  " << i.second<< endl;
		//printf("when writing in file the key is %d\n", i.first);
		//printf("when writing in file the name is %s\n", i.second);

	}
	switch (screen) {
	case 0:
		
		pEngine->setState(&scorestate);
		pEngine->virtInitialise();
		pEngine->redrawDisplay();
		x = 0;
		enternum = 0;

	}

}
