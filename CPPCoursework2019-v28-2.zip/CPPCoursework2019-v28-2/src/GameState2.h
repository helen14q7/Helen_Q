#pragma once
#include "StateEngine.h"
#include"Psyyq2Engine.h"
#include"ScoreState.h"
#include"HighscoreState.h"
#include"PauseState.h"
class GameState2 :
	public StateEngine
{
public:
	GameState2(Psyyq2Engine *pEngine);
	~GameState2();
	void virInitial();
	void virKeyPress(int iKeyCode);
	void drawStringAbove();
	void drawStringUnder();
	void InitialObject();
protected:
	//psyyq2TileManager tm;
	ControllingObject* Co;
	psyyq2TileManager tm;
	PinObject *po;
	PinObject *po1;
	//PinObject *po2;
	//PinObject *po2;
	//PinObject *po3;
	//PinObject *po4;
	//PinObject *po5;
	PinObject *po6;
	//PinObject *po7;
	ShootingObject *sho;
	ShootingObject *sho1;
	ShootingObject *sho2;
	FloatObject *fo;
	FloatObject *fo1;
	FloatObject *fo2;
	Psyyq2Engine *pEngine;
	ScoreState scorestate2;
	HighscoreState scorestate1;
	PauseState *pause = NULL;
	int startTime;
	int startTime2;

public:
	void virtStateChange(int screen);
	void appendObject(int dir);
	void appendObject2(int dir);
};

