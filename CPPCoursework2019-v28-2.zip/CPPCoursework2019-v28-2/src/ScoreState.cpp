#include"header.h"
#include "ScoreState.h"


extern map<int, string, std::greater<int>> highscores;
ScoreState::ScoreState(Psyyq2Engine *pEngine)
	:pEngine(pEngine),over(pEngine)
{
}


ScoreState::~ScoreState()
{
}


void ScoreState::virInitial()
{
	pEngine->fillBackground(0x000000);
	
}


void ScoreState::drawStringAbove()
{

	int x = 150;
	char buff[128];
	pEngine->drawForegroundString(280,100 ,"High Scores", 0xD2691E, NULL);
	//pEngine->drawForegroundString(10, 10, "The Tank", 0xD2691E, NULL);
	for (const auto &i : highscores) {
		//printf("when print the key is %d\n", i.first);
		//printf("when print  the name is %s\n", i.second.c_str());
		sprintf(buff, "Name: %s, Score: %d", i.second.c_str(), i.first);
		pEngine->drawForegroundString(230, x,buff, 0xD2691E, NULL);
		x = x + 50;
	}

}


void ScoreState::virKeyPress(int iKeyCode)
{
	switch (iKeyCode) {
	case SDLK_SPACE:
		pEngine->setState(&over);
		pEngine->virtInitialise();
		pEngine->redrawDisplay();
		
		break;

	}
}
