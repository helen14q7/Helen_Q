#pragma once
#include "StateEngine.h"
#include"Psyyq2Engine.h"
//#include"StartState.h"
class OverState :
	public StateEngine
{
public:
	OverState(Psyyq2Engine *pEngine);
	~OverState();
	void virInitial();
private:
	Psyyq2Engine *pEngine;
	SimpleImage image;
	
public:
	void virKeyPress(int iKeyCode);
};

