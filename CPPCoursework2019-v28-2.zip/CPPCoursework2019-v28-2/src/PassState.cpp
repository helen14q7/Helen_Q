#include"header.h"
#include "PassState.h"



PassState::PassState(Psyyq2Engine *pEngine)
	:pEngine(pEngine),game2(pEngine)
{
}


PassState::~PassState()
{
}


void PassState::virInitial()
{
	pEngine->fillBackground(0x000000);
}






void PassState::drawStringAbove()
{
	pEngine->drawForegroundString(20, 400,"YOU PASSED! PRESS SPACE TO GO TO NEXT LEVEL!", 0xD2691E, NULL);
}




void PassState::virtStateChange()
{
	pEngine->setState(&game2);

	pEngine->virtInitialise();
	
	pEngine->redrawDisplay();
}


void PassState::virKeyPress(int iKeyCode)
{
	switch (iKeyCode) {
		case SDLK_SPACE:
			virtStateChange();
	}
}
