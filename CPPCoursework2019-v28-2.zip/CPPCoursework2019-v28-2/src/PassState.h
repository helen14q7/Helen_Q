#pragma once
#include "StateEngine.h"
#include"Psyyq2Engine.h"
#include"GameState2.h"
class PassState :
	public StateEngine
{
public:
	PassState(Psyyq2Engine *pEngine);
	~PassState();
	void virInitial();
private:
	Psyyq2Engine* pEngine;
	GameState2 game2;
public:
	void drawStringAbove();
	void virtStateChange();
	void virKeyPress(int iKeyCode);
};

