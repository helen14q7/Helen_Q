#pragma once
#include "StateEngine.h"
#include"psyyq2TileManager.h"
#include"Psyyq2Engine.h"
#include"GameState2.h"
#include"PassState.h"
#include"HighscoreState.h"
#include"PauseState.h"
class StateEngine;

class GameState1 :
	public StateEngine
{
public:
	GameState1(Psyyq2Engine *pEngine);
	~GameState1();
	void virInitial();
	void virKeyPress(int iKeyCode);
	void drawStringAbove();
	void drawStringUnder();

protected:
	//psyyq2TileManager tm;
	ControllingObject* Co;
	psyyq2TileManager tm;
	PinObject *po;
	PinObject *po1;
	//PinObject *po2;
	//PinObject *po3;
	//PinObject *po4;
	//PinObject *po5;
	//PinObject *po6;
	//PinObject *po7;
	ShootingObject *sho;
	ShootingObject *sho1;
	ShootingObject *sho2;
	//FloatObject *fo;
	//FloatObject *fo1;
	//FloatObject *fo2;
	Psyyq2Engine *pEngine;
	GameState2 game2;
	//StartState state;
	PassState pass1;
	HighscoreState scorestate;
	ScoreState scorestate2;
	//PauseState pause;
	PauseState *pause = NULL;
	int startTime;
	int startTime2;

public:
	void InitialObject();
	void virtStateChange(int screen);
	void appendObject(int dir);
	void virtMouseMoved(int iX, int iY);
	void appendObject2(int dir);
};

