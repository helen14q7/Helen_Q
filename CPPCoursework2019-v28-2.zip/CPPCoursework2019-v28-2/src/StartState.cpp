#include"header.h"
#include "StartState.h"
#include"BaseEngine.h"
#include"StateEngine.h"
#include<vector>
#include<string>
#include<fstream>
#include<iostream>
#include<string.h>

extern map<int, string, std::greater<int>> highscores;
int game = 0;
int space = 0;
int choose = 0;
int pic = 0;

StartState::StartState(Psyyq2Engine *pEngine)
	:pEngine(pEngine),game1(pEngine), m_filterScaling(0, 0, pEngine), m_filterTranslation(0, 0, &m_filterScaling),game2(pEngine)
	
{
	pEngine->getBackgroundSurface()->setDrawPointsFilter(&m_filterTranslation);
	pEngine->getForegroundSurface()->setDrawPointsFilter(&m_filterTranslation);
}


StartState::~StartState()
{
}


void StartState::virKeyPress(int iKeyCode)
{
	switch (iKeyCode) {
	case SDLK_SPACE:
		if (space == 1) {
			if (game == 1) {
				printf("should be here\n");
				virtStateChange(0);
			}
			if (game == 2) {
				virtStateChange(1);
			}

		}
		
		
		break;
	case SDLK_LEFT:
		printf("hhhheeeee\n");
		m_filterTranslation.changeOffset(10, 0);
		pEngine->redrawDisplay();
		break;
	case SDLK_RIGHT:
		m_filterTranslation.changeOffset(-10, 0);
		pEngine->redrawDisplay();
		break;
	case SDLK_UP:
		m_filterTranslation.changeOffset(0, pEngine->getWindowHeight());
		pEngine->redrawDisplay();
		//int iNewCentreX = pEngine->convertRealToVirtualXPosition(this->pEngine->getWindowWidth() / 2); //the corresponding pixel of the old screen
		//int iNewCentreY = pEngine->convertRealToVirtualXPosition(this->pEngine->getWindowHeight() / 2);
		//printf("the surface%d\n", pEngine->getForegroundSurface()->getSurfaceWidth());
		break;
	case SDLK_DOWN:
		m_filterTranslation.changeOffset(0, -pEngine->getWindowHeight());
		pEngine->redrawDisplay();
		break;
	}
}


void StartState::virInitial()
{
	ifstream inputfile;
	string input;
	int key;
	string name;
	
	inputfile.open("highscores.txt");
	if (inputfile.is_open()) {

		while (inputfile >> key >> name) {
			highscores[key] = name;
			//printf("when loading in file the key is %d\n", key);
			//printf("when loading in file the name is %s\n", name);

		}
		
	}
	else {
		cerr << "Unable to open file !" << endl;
		return;
	}

	inputfile.close();
	pEngine->fillBackground(0x000000);
	
	/*SimpleImage image2 = ImageManager::loadImage("demo.png", true);
	image2.renderImage(pEngine->getBackgroundSurface(), 0, 0, 10, 10,
		image.getWidth(), image.getHeight());
*/
	
}





void StartState::drawStringAbove()
{

	printf("maybeeeeeeeee hewew");
	pEngine->drawForegroundString(150, 50, "THE TANK", 0x800000,pEngine->getFont("Cornerstone Regular.ttf", 80));
	pEngine->drawForegroundString(200, 450, "Choose A Level!", 0xD2691E, pEngine->getFont("Cornerstone Regular.ttf", 40));
	pEngine->drawForegroundString(300, 700, "Tutorial", 0xD2691E, NULL);
	pEngine->drawForegroundString(100, 800, "Use Navigation Pad To Control Tank", 0xD2691E, NULL);
	pEngine->drawForegroundString(100, 850, "Use Space To Shoot", 0xD2691E, NULL);
	pEngine->drawForegroundString(100, 900, "Shoot Enemy and Tile To Get Score", 0xD2691E, NULL);
	pEngine->drawForegroundString(100, 950, "Get Heart To Gain Extra Score And Life", 0xD2691E, NULL);
	if (choose == 0) {
		pEngine->drawForegroundString(300, 1100, "Have Fun !", 0xD2691E, pEngine->getFont("Cornerstone Regular.ttf", 30));
	}
	//pEngine->drawForegroundString(300, 1100, "Have Fun !", 0xD2691E, NULL);
	else {
		pEngine->drawForegroundString(300, 1100, "Start Play !", 0xD2691E, pEngine->getFont("Cornerstone Regular.ttf", 40));
	}
	if (pic == 1) {
		SimpleImage image = ImageManager::loadImage("level1.jpg", true);
		image = image.shrinkBy(2);
		image.renderImage(pEngine->getForegroundSurface(), 0, 0, 50, 50,
			500, 500);
	}
	else if (pic == 2) {
		SimpleImage image2 = ImageManager::loadImage("level2.jpg", true);
		image2 = image2.shrinkBy(2);
		image2.renderImage(pEngine->getForegroundSurface(), 0, 0, 250,50,
			500, 500);
	}
	else {

		SimpleImage image = ImageManager::loadImage("level1.jpg", true);
		image = image.shrinkBy(5);
		image.renderImage(pEngine->getForegroundSurface(), 0, 0, 124, 200,
			200, 200);
		SimpleImage image2 = ImageManager::loadImage("level2.jpg", true);
		image2 = image2.shrinkBy(5);
		image2.renderImage(pEngine->getForegroundSurface(), 0, 0, 468, 200,
			200, 200);
	}
}


//int StartState::virtInitialise()
//{
//	pEngine->getBackgroundSurface()->setDrawPointsFilter(&m_filterTranslation);
//	pEngine->getForegroundSurface()->setDrawPointsFilter(&m_filterTranslation);
//	return pEngine->virtInitialise();
//}



void StartState::virtMouseDown(int iButton, int iX, int iY)
{
	switch (iButton)
	{
	case 1: // Left
		if(124 < iX && iX < 324 && 200 < iY && iY < 400)
		//if ((124 < iX < 324 )&& (200 < iY < 400))
		{
			space = 1;
			game = 1;
			m_filterTranslation.changeOffset(0, -pEngine->getWindowHeight());
			pEngine->redrawDisplay();
			

		}
		if(468 < iX && iX < 668 && 200 < iY && iY< 400) {
			space = 1;
			game = 2;
			m_filterTranslation.changeOffset(0, -pEngine->getWindowHeight());
			pEngine->redrawDisplay();

		}
		if (300 < iX && iX < 400 && 1100 < iY && iY < 1150) {
			if (space == 1) {
				if (game == 1) {
					printf("should be here\n");
					virtStateChange(0);
				}
				if (game == 2) {
					virtStateChange(1);
				}

			}

		}




		break;
	//case 2: // Middle
	//	m_filterScaling.compress();
	//	printf("comppppppreeessss\n");
	//	break;

	//case 3: // Right
	//	m_filterScaling.stretch();
	//	printf("stretchhhhh\n");
	//	break;
	}
	// Redraw the background
	pEngine->redrawDisplay(); // Force total redraw
}


void StartState::virtMouseRoll(int x, int y, int which, int timestamp)
{
	printf("wheeeeeeelll rollling\n");
	int iOldCentreX = pEngine->convertRealToVirtualXPosition(this->pEngine->getWindowWidth() / 2);
	int iOldCentreY = pEngine->convertRealToVirtualXPosition(this->pEngine->getWindowHeight() / 2);
	printf("the old center x is %d\n", iOldCentreX);
	printf("the old center y is %d\n", iOldCentreY);


	if (y < 0) {
		m_filterScaling.compress();
		printf("comppppppreeessss\n");
	}
		
	else if (y > 0)
	{
		m_filterScaling.stretch();
		printf("streeech\n");

	}
		

	// Now we grab the position after the zoom
	int iNewCentreX = pEngine->convertRealToVirtualXPosition(this->pEngine->getWindowWidth() / 2); //the corresponding pixel of the old screen
	int iNewCentreY = pEngine->convertRealToVirtualXPosition(this->pEngine->getWindowHeight() / 2);
	printf("the new center x is %d\n", iNewCentreX);
	printf("the new center y is %d\n", iNewCentreY);
	// Apply a translation to offset so it appears to have zoomed on the centre by moving the old centre back to the centre of the screen
	m_filterTranslation.changeOffset(iNewCentreX - iOldCentreX, iNewCentreY - iOldCentreY);
	// Uncomment the above line to zoom in on centre rather than top left

	// Redraw the background
	pEngine->redrawDisplay(); // Force total redraw
}



void StartState::virtStateChange(int screen)
{
	switch (screen) {
	case 0:
		m_filterTranslation.changeOffset(0, pEngine->getWindowHeight());
		pEngine->setState(&game1);
		printf("hereeeegame1\n");
		pEngine->virtInitialise();
		//pEngine->virtInitialise()
		//printf("hreee222222222\n");
		//m_filterTranslation.changeOffset(0, pEngine->getWindowHeight());
		pEngine->redrawDisplay();
		break;
	case 1:
		m_filterTranslation.changeOffset(0, pEngine->getWindowHeight());
		pEngine->setState(&game2);

		pEngine->virtInitialise();
		//pEngine->virtInitialise()
		//printf("hreee222222222\n");
		//m_filterTranslation.changeOffset(0, pEngine->getWindowHeight());
		pEngine->redrawDisplay();
		break;

	}
}


void StartState::virtMouseMoved(int iX, int iY)
{
	if (300 < iX && iX < 550 && 1100 < iY && iY < 1250) {
		choose = 1;
	}
	else {
		choose = 0;
	}
	if (124 < iX && iX < 324 && 200 < iY && iY < 400) {
		pic = 1;

	}
	else if (468 < iX && iX < 668 && 200 < iY && iY < 400) {
		pic = 2;
	}
	else {
		pic = 0;
	}
	
	
	pEngine->redrawDisplay(); 
	
}
